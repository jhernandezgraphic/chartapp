export { default } from './InlineColorPicker'
