import React from 'react'

export default function Menu() {
  return <div className="bg-primary">Menu</div>
}
